<?php
?>
<html>
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
	<link rel="icon" type="image/ico" href="img/LogoPage2.ico">
	<title>Accueil</title>
</head>
<body>

<div class="main">
	<div class="Menu_vertical">
	<img src="img/Logo + titre.png" width="250" height="220" usemap="#carteMenu"/>
	<ul class="menu">
		<li><a href="index.html"><span>Accueil</span></a></li>
		<li><a href="Pages Boutique/Boutique1.html"><span>Boutique</span></a></li>
		<li><a href="Pages Catalogue/Catalogue1.html"><span>Catalogue</span></a></li>
	</ul>
	</div>
	<div class="bandeauTitre">
	<div class="titre">
		Accueil
		</div>
	</div>
	<div class="contenu">
	<div class="image">
	<img src="img/Logo + titre.png"   usemap="#carteMenu"/></div>
		<div class="presentation">
		<div class="presentationTexte">
		Bienvenue sur le site Geek-Zone ! LE site conscacree a la vente d'objet "Geek" !
		</div>
	</div>
	</div>
</div>

</body>
</html>
