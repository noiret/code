<?php 
 $base='geekzone_vitrine'; 
 $hote='localhost'; 
 $utilisateur='root'; 
 $mdp=''; 
?>