<?php
function affiche($nom)
{
	
}
?>