<?php
include 'function_base.php';
base();
?>
	<div class="bandeauTitre">
	<div class="titre">
		Accueil
		</div>
	</div>
	<div class="contenu">
	<div class="image">
	<img src="img/Logo + titre.png"   usemap="#carteMenu"/></div>
		<div class="presentation">
		<div class="presentationTexte">
		Bienvenue sur le site Geek-Zone ! LE site conscacree a la vente d'objet "Geek" !
		</div>
	</div>
	</div>

</body>
</html>
